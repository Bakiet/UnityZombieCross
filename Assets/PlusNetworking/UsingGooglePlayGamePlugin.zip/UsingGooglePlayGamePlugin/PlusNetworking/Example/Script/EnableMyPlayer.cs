﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class EnableMyPlayer : MonoBehaviour 
{	
//	void Start () 
//	{
//		int i = 1;
//		foreach(GP_Participant p in GooglePlayRTM.instance.currentRoom.participants) 
//		{
//			if(PlayerPrefs.GetInt("myPlayerPos") == i)
//			{
//				GameObject.Find(i.ToString()).GetComponent<PlusNetworkTransform>().enabled = true;
//			}			
//			i++;
//		}
//	}
}
