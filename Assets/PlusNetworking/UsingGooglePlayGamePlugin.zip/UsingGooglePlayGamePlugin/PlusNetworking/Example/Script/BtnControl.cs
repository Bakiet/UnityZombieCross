﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class BtnControl : MonoBehaviour 
{
	public GameObject ConnectBtn;
	public Text ConnectBtnText;
	public GameObject findMatchBtn;
	public GameObject inviteFriendBtn;
	public GameObject showRoomBtn;
	public GameObject leaveRoomBtn;
	public GameObject moveButtons;
	public GameObject blackPlayer;
	public GameObject bluePlayer;
	public GameObject greenPlayer;
	public GameObject redPlayer;	
	bool onetime1;
	bool onetime2;
	bool onetime3;
	bool onetime4;
	bool onetime5;
	// Use this for initialization

}
